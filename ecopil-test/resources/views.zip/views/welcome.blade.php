@extends('layouts.app')

{{-- SEO Meta: Fokus pada Solusi "Tangan Lembut" untuk meningkatkan Klik --}}
@section('title', 'ECOPIL | Sabun Cuci Piring Ramah Lingkungan Jambi - Lembut di Tangan & Anti Lemak')
@section('description', 'Bosan tangan kasar akibat kimia? Pakai ECOPIL, sabun cuci piring ramah lingkungan dari Jambi, bahan alami sabut pinang & lerak. Non-iritan, aman untuk kulit sensitif, dan efektif angkat lemak.')
@section('keywords', 'sabun cuci piring ramah lingkungan jambi, ecopil, sabun cuci piring alami')

@section('og_title', 'ECOPIL - Sabun Cuci Piring Ramah Lingkungan Jambi')
@section('og_description', 'Solusi cuci piring ramah lingkungan dari Jambi, bahan organik sabut pinang & lerak. Aman untuk keluarga dan lingkungan.')
@section('page_headline', 'Cuci Piring Bersih - Tangan Tetap Lembut dengan Kekuatan Alam')
@section('page_section', 'Pilih Varian Sabun Cuci Piring Ramah Lingkungan ECOPIL')
@section('og_image', asset('images/Ecopil.png'))

@section('content')
    {{-- Pembungkus utama dengan animasi masuk agar tidak membosankan --}}
    <div class="animate-fade-in">
        
        {{-- Hero Section: Pintu utama penentu konversi --}}
        @include('components.hero')

        {{-- Features: Memberikan alasan logis untuk tetap scroll --}}
        <div class="relative overflow-hidden">
            {{-- Dekorasi latar belakang lembut untuk memecah kebosanan --}}
            <div class="absolute top-0 left-0 w-full h-20 bg-gradient-to-b from-white to-gray-50"></div>
            @include('components.features')
        </div>

        {{-- Products: Menampilkan varian dan harga --}}
        @include('components.products')

        {{-- Order: Call to Action utama --}}
        <div class="bg-gray-50 py-10">
            @include('components.order')
        </div>

        {{-- Testimonials: Membangun kepercayaan (Social Proof) --}}
        @include('components.testimonials')

        {{-- Article: Konten edukasi tentang ECOPIL --}}
        @include('components.article')

        {{-- FAQ: Menghilangkan keraguan terakhir sebelum beli --}}
        <div class="bg-white">
            @include('components.faq')
        </div>

    </div>
@endsection

@push('scripts')
<script>
    // Script tambahan khusus halaman beranda jika diperlukan
    document.addEventListener('DOMContentLoaded', function() {
        console.log('ECOPIL Landing Page Loaded with Fresh Design');
    });
</script>
@endpush