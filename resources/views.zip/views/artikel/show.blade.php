@extends('layouts.app')

@section('title', $article['title'] . ' — ECOPIL | Sabun Cuci Piring Alami')
@section('description', $article['description'])
@section('keywords', $article['keywords'])
@section('og_title', $article['title'])
@section('og_description', $article['description'])
@section('og_image', asset($article['image']))

@section('content')

{{-- Reading Progress --}}
<div id="reading-progress"
     class="fixed top-0 left-0 z-50 h-1 bg-[#2e7d32]"
     style="width:0%">
</div>

<main class="bg-gray-50 min-h-screen">

    {{-- HERO --}}
    <section class="relative overflow-hidden bg-gradient-to-br from-green-50 via-white to-orange-50 border-b border-gray-100">

        <div class="absolute inset-0 opacity-10">
            <div class="absolute top-10 left-10 w-72 h-72 bg-green-500 rounded-full blur-3xl"></div>
            <div class="absolute bottom-10 right-10 w-72 h-72 bg-orange-400 rounded-full blur-3xl"></div>
        </div>

        <div class="relative max-w-5xl mx-auto px-6 py-16">

            {{-- Breadcrumb --}}
            <nav class="flex items-center gap-2 text-sm text-gray-500 mb-8">
                <a href="{{ url('/') }}" class="hover:text-[#2e7d32]">
                    Beranda
                </a>

                <span>/</span>

                <a href="{{ route('artikel.index') }}"
                   class="hover:text-[#2e7d32]">
                    Artikel
                </a>

                <span>/</span>

                <span class="text-gray-700">
                    {{ $article['title'] }}
                </span>
            </nav>

            <span class="inline-block bg-green-100 text-[#2e7d32]
                         px-4 py-2 rounded-full text-xs
                         font-bold uppercase tracking-wider mb-5">
                {{ $article['label'] }}
            </span>

            <h1 class="text-4xl md:text-5xl font-extrabold
                       text-gray-900 leading-tight max-w-4xl">
                {{ $article['title'] }}
            </h1>

            <div class="flex flex-wrap items-center gap-5 mt-6 text-sm text-gray-500">

                <span>✍ Tim ECOPIL</span>

                <span>•</span>

                <span>📖 5 Menit Baca</span>

                <span>•</span>

                <span>🌱 Artikel Edukasi</span>

            </div>
        </div>
    </section>

    {{-- THUMBNAIL --}}
    <div class="max-w-5xl mx-auto px-6 pt-10">

        <div class="overflow-hidden rounded-3xl shadow-xl">

            <img src="{{ asset($article['image']) }}"
                 alt="{{ $article['alt'] }}"
                 class="w-full h-[350px] md:h-[500px] object-cover">

        </div>

    </div>

    {{-- KONTEN --}}
    <div class="max-w-7xl mx-auto px-6 py-14">

        <div class="grid lg:grid-cols-4 gap-12">

            {{-- SIDEBAR --}}
            <aside class="hidden lg:block">

                <div class="sticky top-24">

                    <div class="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm">

                        <h3 class="font-bold text-gray-900 mb-4">
                            Daftar Isi
                        </h3>

                        <ul class="space-y-3 text-sm">

                            <li>
                                <a href="#"
                                   class="text-gray-600 hover:text-[#2e7d32]">
                                    Pendahuluan
                                </a>
                            </li>

                            <li>
                                <a href="#"
                                   class="text-gray-600 hover:text-[#2e7d32]">
                                    Pembahasan
                                </a>
                            </li>

                            <li>
                                <a href="#"
                                   class="text-gray-600 hover:text-[#2e7d32]">
                                    Kesimpulan
                                </a>
                            </li>

                        </ul>

                    </div>

                </div>

            </aside>

            {{-- ISI ARTIKEL --}}
            <article class="lg:col-span-3">

                <div class="
                    bg-white
                    rounded-3xl
                    shadow-sm
                    border
                    border-gray-100
                    p-8
                    md:p-12

                    prose
                    prose-lg
                    lg:prose-xl

                    max-w-none

                    prose-headings:text-[#2e7d32]
                    prose-headings:font-bold

                    prose-h2:mt-14
                    prose-h2:mb-6

                    prose-h3:mt-10
                    prose-h3:mb-4

                    prose-p:text-gray-700
                    prose-p:leading-8

                    prose-strong:text-gray-900
                ">

                    {{-- =====================================================
                         SELURUH KONTEN ARTIKEL YANG SUDAH ADA
                         (SEMUA @if ARTICLE SLUG MILIKMU)
                         TARUH DI SINI TANPA PERLU DIUBAH
                    ===================================================== --}}

                    @if ($article['slug'] === '...')
                        ...
                    @endif

                    {{-- CTA --}}
                    <div class="mt-16 not-prose">

                        <div class="
                            bg-gradient-to-r
                            from-[#2e7d32]
                            to-[#43a047]
                            rounded-3xl
                            p-10
                            text-white
                        ">

                            <h3 class="text-3xl font-bold mb-3">
                                Mulai Beralih ke Sabun yang Lebih Aman
                            </h3>

                            <p class="text-green-100 mb-6">
                                Lindungi kulit tangan, keluarga,
                                dan lingkungan mulai dari dapur rumahmu.
                            </p>

                            <a href="{{ url('/#produk') }}"
                               class="
                                    inline-flex
                                    items-center
                                    bg-white
                                    text-[#2e7d32]
                                    px-6
                                    py-3
                                    rounded-xl
                                    font-bold
                                    hover:scale-105
                                    transition
                               ">
                                Lihat Produk ECOPIL →
                            </a>

                        </div>

                    </div>

                </div>

            </article>

        </div>

    </div>

    {{-- ARTIKEL LAINNYA --}}
    <section class="max-w-7xl mx-auto px-6 pb-20">

        <h2 class="text-3xl font-bold text-gray-900 mb-8">
            Artikel Lainnya
        </h2>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">

            @foreach ($otherArticles as $other)

                <a href="{{ route('artikel.show', $other['slug']) }}"
                   class="
                        group
                        bg-white
                        rounded-3xl
                        overflow-hidden
                        shadow-sm
                        hover:shadow-xl
                        transition
                   ">

                    <img src="{{ asset($other['image']) }}"
                         alt="{{ $other['alt'] }}"
                         class="w-full h-48 object-cover
                                group-hover:scale-105 transition duration-300">

                    <div class="p-5">

                        <span class="text-xs uppercase font-bold text-[#2e7d32]">
                            {{ $other['label'] }}
                        </span>

                        <h3 class="mt-2 font-semibold text-gray-900">
                            {{ $other['title'] }}
                        </h3>

                    </div>

                </a>

            @endforeach

        </div>

    </section>

</main>

<script>
window.addEventListener('scroll', () => {

    const winScroll =
        document.body.scrollTop ||
        document.documentElement.scrollTop;

    const height =
        document.documentElement.scrollHeight -
        document.documentElement.clientHeight;

    const scrolled =
        (winScroll / height) * 100;

    document.getElementById('reading-progress')
        .style.width = scrolled + '%';
});
</script>

@endsection